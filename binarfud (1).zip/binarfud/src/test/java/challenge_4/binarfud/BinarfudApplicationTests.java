package challenge_4.binarfud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BinarfudApplicationTests {

	@Test
	void contextLoads() {
	}

}
